using Microsoft.AspNetCore.Mvc;
using Services;
using Domain;
using System.Collections.Generic;
using System.Threading.Tasks;

[Route("api/[controller]")]
[ApiController]
public class OrdersController : ControllerBase
{
    private readonly OrderService _orderService;

    public OrdersController(OrderService orderService)
    {
        _orderService = orderService;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<Order>>> GetOrders()
    {
        return await _orderService.GetAllOrdersAsync();
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<Order>> GetOrder(int id)
    {
        var order = await _orderService.GetOrderByIdAsync(id);

        if (order == null)
        {
            return NotFound();
        }

        return order;
    }

    [HttpPost]
    public async Task<ActionResult<Order>> PostOrder(Order order)
    {
        await _orderService.AddOrderAsync(order);
        return CreatedAtAction(nameof(GetOrder), new { id = order.Id }, order);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> PutOrder(int id, Order order)
    {
        if (id != order.Id)
        {
            return BadRequest();
        }

        await _orderService.UpdateOrderAsync(order);
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteOrder(int id)
    {
        await _orderService.DeleteOrderAsync(id);
        return NoContent();
    }

    [HttpGet("customer/{customerId}")]
    public async Task<ActionResult<IEnumerable<Order>>> GetOrdersByCustomerId(int customerId)
    {
        return await _orderService.GetOrdersByCustomerIdAsync(customerId);
    }

    [HttpGet("customer/{customerId}/total")]
    public async Task<ActionResult<decimal>> GetTotalPriceByCustomerId(int customerId)
    {
        return await _orderService.GetTotalPriceByCustomerIdAsync(customerId);
    }

    [HttpGet("total-per-customer")]
    public async Task<ActionResult<Dictionary<int, decimal>>> GetTotalPricePerCustomer()
    {
        return await _orderService.GetTotalPricePerCustomerAsync();
    }
}
