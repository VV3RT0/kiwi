﻿using System;

namespace Data
{
    public class Class1
    {
    }
}
